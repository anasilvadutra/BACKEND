const entrada = require('readline-sync');
  
function calcularDesconto(precoOriginal) {
    return precoOriginal * 0.85;
}

const produtos = ["monitor", "teclado", "mouse"];
const precos = [800, 150, 80];

console.log("=== TABELA DE PREÇOS COM DESCONTO (15%) ===");
for (let i = 0; i < produtos.length; i++) {
    let precoComDesconto = calcularDesconto(precos[i]);

    console.log(`${produtos[i]}: de R$ ${precos[i].toFixed(2)} por R$ ${precoComDesconto.toFixed(2)}`);

}
