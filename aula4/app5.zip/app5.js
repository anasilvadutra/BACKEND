const entrada = require('readline-sync');

console.log("--- SISTEMA DE ANALISE DE CREDITO ---")

//Coleta de dados
const nome = entrada.question("Nome do cilente; ")
const idade = entrada.questionInt("Idade: ")
const renda = entrada.questionFloat("Renda mensal: ")
const temImovel = entrada.keyInYNStrict("Possui imovel proprio? "); // Essa função le Y para true e N para false 

//A lógica combinada
//(idade >=18) é obrigatorio
// (renda >= 2.500 || temImovel === true) um dos dois tem que ser verdade
if (idade >= 18 && (renda >= 2500 || temImovel === true)) {
    console.log(`\nPARABENS, ${nome}! seu credito foi aprovado!`);
} else {
    console.log(`\nSinto muito, ${nome}. seu credito foi negado.`);
}
