let contador = 0;

while (contador <= 100) {
    console.log(`Contagem: ${contador}`);
    contador +=2 // Isso aumenta 1 no computador (IMPORTANTE!)
}
console.log("Fim da contagem!")