const entrada = require('readline-sync')

console.log("--- CONTROLE DE VELOCIDADE ---")

const nome = entrada.question ("Nome do motorista: ")
const velocidade = entrada.questionFloat("Sua velocidade? ")

if (velocidade >= 80) {
    console.log("Você levou multa")
} else {
    console.log("Pode prosseguir viajem")
}
