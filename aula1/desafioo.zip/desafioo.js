const entrada = require('readline-sync');

const nome = entrada.question("Nome: ");
const anoNascimento = entrada.questionInt("Ano de nascimento: ");

const anoAtual = 2026;
const idade = anoAtual - anoNascimento;

console.log(`\nNome: ${nome}`);
console.log(`Ano de nascimento: ${anoNascimento}`);
console.log(`Idade: ${idade} anos`);

if (idade >= 18) {
    console.log("Voce pode votar! ");
} else if (idade === 16 || idade === 17) {
    console.log("Voce pode voltar mais nao e obrigatorio! ");
} else {
    console.log("Voce nao pode votar! ");
}